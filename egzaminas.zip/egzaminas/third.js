const ItemId = localStorage.getItem("ItemId");

console.log("ItemId", ItemId);

const getOneItem = () => {
  fetch(
    `https://634437b5dcae733e8fda718c.mockapi.io/shop/${ItemId}`
  )
    .then((response) => {
      return response.json();
    })
    .then((data) => {
      console.log(data);

      const titleWrapper = document.getElementById("Title");
      titleWrapper.innerHTML = data.productinfo;

      const City = document.getElementById("city");
      City.innerHTML = data.City;

      const Photo = document.getElementById("Photo");
      Photo.src = data.photo;

      const priceWrapper = document.getElementById("price");
      priceWrapper.innerHTML = data.price;

      const nameWrapper = document.getElementById("name");
      nameWrapper.innerHTML = data.name;
      
      const button = document.createElement("button");
      button.innerHTML = "Istrinti"
      button.addEventListener('click', () => {
      deleteItem(data.id);
            });
            document.body.append (button);
    });
};
 
    getOneItem();

    const alertMsg = () =>  {
      alert("Katės čia nebėra, bet daugiau kačių pradiniame puslapyje!");
      window.location.href = './first.html';
    };
    
    const deleteItem = (id) => {
    fetch(`https://634437b5dcae733e8fda718c.mockapi.io/shop/${ItemId}`,
    {method: 'DELETE',
     headers: { Accept: 'application/json',
                        'Content-Type': 'application/json',
                },
            }
        )
        .then((res) => {
        console.log('Product was deleted successfully');
        document.body.innerHTML = "";
    
                const myTimeout = setTimeout(alertMsg, 2000);
               
            })
    
      .catch((err) => {
      console.log('err', err);
            });
    
    }; 
    
    
