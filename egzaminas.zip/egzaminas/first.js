fetch("https://634437b5dcae733e8fda718c.mockapi.io/shop")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    console.log("data", data);
    data.sort ((a,b) => a.price-b.price);

    const itemsWrapper = document.getElementById("items");

    data.forEach((item) => {
        const itemWrapper = document.createElement("div");
        itemWrapper.classList.add("item");

    const ImageWrapper = document.createElement("div");
    ImageWrapper.classList.add("image");
    ImageWrapper.style.backgroundImage = `url(${item.photo})`;
    

    const buttonSection = document.createElement("div");
    buttonSection.classList.add("button")
    const button = document.createElement("div");
    button.innerHTML = item.name;
    
  

    button.addEventListener("click", () => {
      localStorage.setItem("ItemId", item.id);
      window.location.replace("./third.html");
    });

    const priceSection = document.createElement("div");
    priceSection.innerHTML = `${item.price}$`;
    priceSection.classList.add("price-section");

    buttonSection.append(button);
    itemsWrapper.append(itemWrapper);
    itemWrapper.append (ImageWrapper, buttonSection, priceSection);
    });
  });