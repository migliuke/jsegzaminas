const submitForm = document.querySelector("form");

const postData = async (product) => {
    const alertMsg = document.getElementById("alert");
    try {
        const response = await fetch("https://634437b5dcae733e8fda718c.mockapi.io/shop", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(product),
        });
        if (response.ok) {
            alertMsg.innerHTML = "Sveikinu pridėjai katę!";
        }
    } catch (error) {
        alertMsg.innerHTML = `There was an error! Try again later!\n${error}`;
    }
};

const addProduct = (event) => {
    event.preventDefault();
    const productImageInput = document.getElementById("image");
    const productPriceInput = document.getElementById("price");
    const productTitleInput = document.getElementById("name");
    const productCityInput = document.getElementById("city");
    const productAboutInput = document.getElementById("about");
  

    const product = {
        image: productImageInput.value,
        price: productPriceInput.value,
        name: productTitleInput.value,
        city: productCityInput.value,
        about: productAboutInput.value,
    };
    postData(product);
};

submitForm.addEventListener("submit", addProduct);