# jsegzaminas
